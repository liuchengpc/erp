package com.apatech.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.apatech.domain.Sales_quotation;
import com.apatech.domain.Team;

public interface Sales_quotationMapper {

 List<Sales_quotation> selectAll();

	 
	 @Select("SELECT \r\n" + 
	 		"CASE\r\n" + 
	 		"WHEN COUNT(*)>98 THEN COUNT(*)+1\r\n" + 
	 		"WHEN COUNT(*)>8 THEN CONCAT('0',COUNT(*)+1)\r\n" + 
	 		"ELSE CONCAT('00',COUNT(*)+1)\r\n" + 
	 		"END \r\n" + 
	 		"FROM\r\n" + 
	 		"Sales_quotation WHERE sq_custom1=#{billdate}")
    String getno(@Param("billdate")String billdate);
	
    int deleteByPrimaryKey(String sqId);

    int insert(Sales_quotation record);

    int insertSelective(Sales_quotation record);

    Sales_quotation selectByPrimaryKey(String sqId);

    int updateByPrimaryKeySelective(Sales_quotation record);

    int updateByPrimaryKey(Sales_quotation record);
}